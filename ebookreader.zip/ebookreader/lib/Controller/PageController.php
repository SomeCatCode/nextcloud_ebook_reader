<?php

declare(strict_types=1);

/**
 * SPDX-FileCopyrightText: 2026 Felix Kurth
 * SPDX-License-Identifier: AGPL-3.0-or-later
 */

namespace OCA\EbookReader\Controller;

use OCA\EbookReader\AppInfo\Application;
use OCA\EbookReader\Service\SettingsService;
use OCP\AppFramework\Controller;
use OCP\AppFramework\Http\Attribute\FrontpageRoute;
use OCP\AppFramework\Http\Attribute\NoAdminRequired;
use OCP\AppFramework\Http\Attribute\NoCSRFRequired;
use OCP\AppFramework\Http\TemplateResponse;
use OCP\AppFramework\Services\IInitialState;
use OCP\IRequest;
use OCP\IUserSession;
use OCP\L10N\IFactory;
use OCP\Util;

class PageController extends Controller {
	/** Languages written right to left (primary language subtag). Nextcloud sets dir for them itself; the app repeats it for its own language. */
	private const RTL_LANGUAGES = ['ar', 'fa', 'he', 'ps', 'ug', 'ur'];

	public function __construct(
		IRequest $request,
		private IInitialState $initialState,
		private SettingsService $settings,
		private IUserSession $userSession,
		private IFactory $l10nFactory,
	) {
		parent::__construct(Application::APP_ID, $request);
	}

	#[NoAdminRequired]
	#[NoCSRFRequired]
	#[FrontpageRoute(verb: 'GET', url: '/')]
	public function index(): TemplateResponse {
		return $this->render();
	}

	#[NoAdminRequired]
	#[NoCSRFRequired]
	#[FrontpageRoute(verb: 'GET', url: '/read/{fileId}')]
	public function read(int $fileId): TemplateResponse {
		return $this->render();
	}

	#[NoAdminRequired]
	#[NoCSRFRequired]
	#[FrontpageRoute(verb: 'GET', url: '/edit/{fileId}')]
	public function edit(int $fileId): TemplateResponse {
		return $this->render();
	}

	private function render(): TemplateResponse {
		$user = $this->userSession->getUser();
		if ($user !== null) {
			$this->initialState->provideInitialState('settings', $this->settings->get($user->getUID()));
		}
		// The language of the app's translations can differ from the one of the page (the app may use a different one, e.g. when core has no translation for it).
		$language = $this->l10nFactory->findLanguage(Application::APP_ID);
		$this->initialState->provideInitialState('l10n', [
			'language' => $language,
			'rtl' => in_array(strtolower(explode('_', $language)[0]), self::RTL_LANGUAGES, true),
		]);
		// l10n/<lang>.js (OC.L10N.register) for t()/n() in the frontend; addScript() would add it too.
		Util::addTranslations(Application::APP_ID);
		Util::addScript(Application::APP_ID, 'ebookreader-main');
		Util::addStyle(Application::APP_ID, 'ebookreader-main');
		return new TemplateResponse(Application::APP_ID, 'main');
	}
}
