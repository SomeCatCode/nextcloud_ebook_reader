# Changelog

Alle nennenswerten Änderungen an dieser App werden hier dokumentiert.
Das Format folgt [Keep a Changelog](https://keepachangelog.com/de/1.1.0/), die Versionen folgen [Semantic Versioning](https://semver.org/lang/de/).

## [Unreleased]

## 1.0.0 – 2026-10-29

### Hinzugefügt
- **Longstrip-Comics (Webtoons):** Ein als Longstrip markierter Comic wird im Reader nicht geblättert, sondern nahtlos nach unten gescrollt. Alle Seiten liegen ohne Abstand untereinander, Bilder werden in der Nähe des sichtbaren Bereichs geladen und weiter entfernt wieder freigegeben, sodass auch Bände mit Tausenden Seiten flüssig bleiben. Die Position innerhalb einer hohen Seite wird mitgespeichert. Seitliche Tipp-Zonen, Leertaste und Bild-Tasten scrollen eine Bildschirmhöhe, die Pfeiltasten in kleinen Schritten. Zoom: Originalbreite (höchstens Bildschirmbreite) oder Bildschirmbreite.
- Erkennung beim Indizieren aus ComicInfo.xml (`Format` „Webtoon“, „Long Strip“ oder „Vertical“, oder ein solcher Tag bzw. ein solches Genre). Die Markierung lässt sich in den Buchdetails, in der Massenbearbeitung und direkt in den Reader-Einstellungen („Darstellung: Seiten / Longstrip“) ändern. Ein von Hand gesetzter Wert übersteht das erneute Indizieren und lässt sich auf den Wert aus der Datei zurücksetzen.
- Bei Longstrip-Comics trägt das Format-Abzeichen auf der Karte und in der Liste den Zusatz „-LS“ (z. B. „CBZ-LS“). In der Navigation gibt es die Gruppe „Darstellung“ mit dem Filter `layout:longstrip`.
- API: Das Buch-JSON hat `longstrip` und `longstripManual`. `PATCH /books/{fileId}/app-data` und `PATCH /books/app-data` kennen `longstrip` (true/false) und `resetLongstrip`. Die Facetten haben `layouts` mit der Anzahl der Longstrip-Comics. Neue Spalten `longstrip`, `longstrip_file`, `longstrip_manual` (Migration `Version1009Date20261025100000`). Bereits indizierte Comics erhalten den Wert aus der Datei beim nächsten Scan mit `--force`.
- **Lesevorschläge:** Am Ende eines Buchs zeigt der Reader „Fertig gelesen“ mit „Weiterlesen: <nächster Band>“ und 3–4 ähnlichen, ungelesenen Titeln. Der Block erscheint auch in den Details gelesener Bücher und lässt sich schließen. Ähnlich heißt: mindestens ein gemeinsamer Autor, ein Genre oder ein Tag; Sprache und Comic/E-Book verbessern nur die Reihenfolge. Pro Serie erscheint höchstens ein Titel (ihr erster ungelesener Band), Bände derselben Serie nie. Das Ende ist die letzte Seite bzw. Doppelseite, beim Longstrip und bei gescrolltem Text das untere Ende; die Prozentanzeige zählt dafür nicht. Neuer Endpunkt `GET /api/v1/books/{fileId}/suggestions` (Capability-Feature `suggestions`).
- Fehlt die Bandnummer in den Metadaten, liest der Server sie beim Indizieren aus Titel oder Dateiname (z. B. „Vol. 10“, „v02“, „Band 3“, „#7“, „Tome 4“, „第3巻“, „Saga 10“; Jahreszahlen zählen nicht). Eine Nummer aus den Metadaten oder aus dem Editor hat immer Vorrang. Capability-Feature `series-order`; Migration `Version1010Date20261027100000` (Spalten `title_sort` und `series_index_derived`, für vorhandene Bücher gefüllt).
- **Lesen über öffentliche Linkfreigaben:** Ein Gast mit Freigabe-Link kann ein Buch jetzt im Browser lesen. Eine Anmeldung ist nicht nötig. Der Reader öffnet sich in der Dateien-Vorschau der Freigabeseite. Er funktioniert für eine geteilte Datei und für Bücher in einem geteilten Ordner. Bei einer Freigabe mit Passwort gibt der Gast zuerst das Passwort auf der Freigabeseite ein.
  - Der Gast hat Inhaltsverzeichnis, Suche, Einstellungen und Vollbild. Markierungen, Lesezeichen und Vorschläge gibt es ohne Konto nicht.
  - Der Browser speichert Position und Einstellungen. Der Server speichert nichts.
  - Bei „Download verbergen“ oder ohne Download-Recht gibt der Server die Datei nicht heraus. Der Reader zeigt dann einen Hinweis.
  - Neue Routen `GET /s/{token}` (Reader-Seite) und `GET /s/{token}/file` (Buchdatei, mit HTTP-Range, höchstens 60 Aufrufe pro Minute).
- **Bildfilter für Comics:** Die Reader-Einstellungen haben für Comics die Regler „Helligkeit“ und „Kontrast“ (50–200 %) und den Schalter „Graustufen“. Der Filter gilt nur für die Seitenbilder, der Hintergrund bleibt unverändert. Die Werte gelten für alle Comics und auch im Longstrip. „Bild zurücksetzen“ stellt das Originalbild wieder her. Neue Reader-Einstellungen `comicBrightness`, `comicContrast`, `comicGrayscale`.
- **Freigaben eines Buchs ansehen und entfernen:** Die Buchdetails haben den neuen Reiter „Freigaben“. Der Reiter zeigt alle Personen, die das Buch lesen können, und die Freigabe, die den Zugriff gibt:
  - Freigaben der App: Buch, Regal, Serie oder Ordner.
  - Nextcloud-Freigaben der Datei oder eines übergeordneten Ordners: Benutzer, Gruppen, öffentliche Links, E-Mail, Teams, Talk. Weiterteilungen durch Empfänger erscheinen mit dem Namen der Person.
  - Der Dialog „Teilen“ eines Buchs zeigt dieselbe Liste. Ein Buch, das über seine Serie geteilt ist, erscheint dort nicht mehr als „Noch mit niemandem geteilt“.
  - Das Kreuz entfernt eine Freigabe. Vorher zeigt der Reiter die Folge, z. B. „Das ganze Regal … wird nicht mehr geteilt“ oder „Die Freigabe endet für alle Dateien im Ordner“.
  - Neue Endpunkte `GET /api/v1/books/{fileId}/access` und `DELETE /api/v1/books/{fileId}/access?shareId=…` (nur Nextcloud-Freigaben; Freigaben der App entfernen ihre eigenen Endpunkte). Capability-Feature `book-access`.

### Geändert
- **Bearbeiten-Ansicht:** Unter den Metadaten gibt es den Abschnitt „Bibliothek“ mit denselben Feldern wie in den Buchdetails: Bewertung, Lesestatus, Abschluss-Status, Altersfreigabe und Longstrip. Die Werte werden sofort gespeichert; die Buchdatei bleibt unverändert.
- **Unterstützte Nextcloud-Versionen: 33 bis 35.** Nextcloud 31 und 32 entfallen. Die Kompatibilitäts-Shims dafür sind entfernt (`Compat`-Klasse, Fallback für `window._nc_fileactions`); die Server-APIs `IAppManager::isEnabledForAnyone`, `IFilenameValidator::sanitizeFilename` und `IShare::canSeeContent` werden direkt genutzt. CI prüft nur noch 33–35.
- **Bände sortieren natürlich nach Bandnummer:** „Band 2“ steht vor „Band 10“ (Sortierung „Serie“, Serienansicht, `GET /series`, OPDS, „Als Nächstes“). Auch die Sortierung „Titel“ ist natürlich. Bände ohne Nummer stehen immer am Ende.
- **Umbenennen/Einsortieren mit führenden Nullen:** `{series_index}` schreibt die Bandnummer passend zur höchsten Nummer der Serie (01–99, ab 100 Bänden 001); Dezimalzahlen behalten den Bruch (05.5). `{series_index:raw}` schreibt ohne Nullen, `{series_index:N}` genau N Stellen. **Achtung:** Bestehende Muster mit `{series_index}` erzeugen jetzt „02“ statt „2“.

### Behoben
- Dialog „Teilen“: Die Suche nach der Benutzer-ID fand den Benutzer auf dem Server, die Auswahlliste blendete den Treffer aber aus, wenn der Anzeigename anders lautet. Die Liste zeigt jetzt alle Treffer des Servers.
- `GET /series`: `coverFileIds` und `firstFileId` ordneten Titel ohne Bandnummer nicht natürlich.
- Hilfetext für das Dateinamen-Muster nannte den ungültigen Platzhalter `{index}`; richtig ist `{series_index}`.
- **Eigene Tags und Genres gehen nicht mehr verloren,** wenn ein Buch kurz aus der Bibliothek verschwindet (Papierkorb und Wiederherstellen, Verschieben und Zurückschieben, Freigabe neu, Ordner kurz nicht erreichbar). Die Tags bleiben am gelöschten Eintrag und kommen mit dem Buch zurück. Der tägliche Aufräum-Job löscht sie erst zusammen mit dem Eintrag nach 30 Tagen.

### Sicherheit
- **Grenzen für Markierungen und Tags:** Ein Benutzer hat höchstens 100 000 Markierungen, Notizen und Lesezeichen über alle Bücher. Pro Buch bleiben es höchstens 5000. Ist die Grenze erreicht, zeigt der Reader eine klare Meldung und sendet keine Anfrage. Ein Buch hat höchstens 100 App-Tags und 100 App-Genres.
- **Reader: Skripte in präparierten Büchern.** Der Reader setzt die Content-Security-Policy jetzt in einen eigenen `<head>`, der das erste Element jedes Kapitels ist. Bisher ließ sich die Regel umgehen: mit einem `<head>` nach dem `<body>`, einem `<head>` in einem fremden Namespace oder einem Skript vor dem `<head>`. Zusätzlich entfernt der Reader aus jedem Kapitel Skripte, `on*`-Attribute, `javascript:`-Links, `<meta http-equiv>` (z. B. Refresh), `<base>`, Frames, Plugins, `<?xml-stylesheet?>` und SVG-Animationen, die Links ändern.
- **Reader: iframe-Attribut `csp`.** Die Kapitel-iframes tragen dieselbe Regel als Attribut `csp`. Chromium und die Android-WebView setzen sie unabhängig vom Inhalt des Kapitels durch. `docs/SECURITY-READER.md` beschreibt jetzt richtig, dass die Sandbox mit `allow-same-origin` keine Isolation bietet.
- **Reader: Entpacken im Browser begrenzt.** Höchstens 100 000 Einträge und 256 MB pro Eintrag. Bei ZIP (EPUB, CBZ) zählt der Reader die entpackten Bytes; eine ZIP-Bombe bricht an der Grenze ab. Bei CBR/CB7/CBT prüft der Reader die angegebene und die tatsächliche Größe.
- **libarchive im Browser aktualisiert:** Die WASM-Datei für CBR/CB7/CBT im Browser enthält jetzt libarchive 3.8.10 statt 3.7.2 (behobene Fehler im RAR-, 7z- und TAR-Parser). Sie ist selbst gebaut, ohne OpenSSL; Bauanleitung in `packages/libarchive/README.md`. Das Paket enthält nur noch diesen Worker. Vorher kopierte der Build zusätzlich den alten, ungenutzten Worker aus npm.
- **Comic-Seiten-Cache begrenzt:** Der Cache der skalierten Comic-Seiten in den App-Daten zählt zu keinem Kontingent. Er hat jetzt eine Obergrenze (App-Einstellung `comic_cache_mb`, Standard 2048). Darüber entfernt der Server die ältesten Seiten. Eine Seite, die nicht verkleinert werden muss, liegt nur noch einmal im Cache statt einmal pro Breitenstufe. `GET /comic/{fileId}/pages` hat ein Limit (120 Aufrufe pro Minute und Benutzer). Eine nicht lesbare Seitenliste merkt sich der Server 10 Minuten, statt 7z oder unrar bei jedem Aufruf neu zu starten.
- **Grenzen für Metadaten:** Beschreibungen haben höchstens 64 KB (längere werden als gekürzter Text gespeichert, gelesen werden höchstens 256 KB). Autoren, Genres, Tags und Schlagwörter sind auf je 100 Einträge begrenzt, Namen auf 255 Zeichen. Das OPF-Paketdokument eines EPUB darf höchstens 4 MB groß sein, `container.xml` 64 KB, `ComicInfo.xml` in CBZ 5 MB. Ein präpariertes Buch kann so den PHP-Speicher nicht mehr sprengen.

## 0.11.1 – 2026-10-13

### Geändert
- **Unterstützte Nextcloud-Versionen: 31 bis 35** (bisher nur 34). Nextcloud 35 wird damit unterstützt; auf einem auf 35 aktualisierten Server wurde die App vorher wegen `max-version` deaktiviert, und der Cron meldete u. a. „Could not resolve OCA\EbookReader\BackgroundJob\SyncSharedShelvesJob“. Neuere Server-APIs (`IAppManager::isEnabledForAnyone`, `IFilenameValidator::sanitizeFilename`, `IShare::canSeeContent`) werden mit abgesicherten Fallbacks genutzt, damit Nextcloud 31 weiter funktioniert.

### Hinzugefügt
- CI: Psalm läuft gegen die OCP-Stubs aller unterstützten Nextcloud-Versionen (31–35, zusätzlich `master` als Vorwarnung). Ein Integrationstest installiert die App in ein echtes Nextcloud (31–35, mehrere PHP-Versionen, SQLite), lädt ein Test-EPUB hoch, scannt die Bibliothek, ruft die wichtigsten API-Endpunkte und die Web-Oberfläche auf und führt die Hintergrundjobs der App aus.

### Behoben
- Die Zeile „Weiterlesen“ unter „Alle Bücher“ zeigt jetzt dieselben Bücher wie der Menüpunkt „Weiterlesen“ (Lesestatus „Wird gelesen“, zuletzt gelesene zuerst), wie schon das Dashboard-Widget. Bisher entschied der Lesefortschritt: Bücher mit Status „Wird gelesen“ ohne Fortschritt fehlten, und die Auswahl wich vom Menüpunkt ab.

## 0.11.0 – 2026-10-13

### Hinzugefügt
- **Neue Sprachen:** Die App ist jetzt auch auf **Französisch**, **Arabisch** (Hocharabisch), **Türkisch** und **Persisch** (`fa`) verfügbar – zusätzlich zu Deutsch, Englisch, Spanisch und Japanisch, also in denselben Sprachen wie die Android-App. Alle Oberflächentexte sind übersetzt (inklusive der Pluralformen, bei Arabisch mit allen sechs); Name, Kurzbeschreibung und Beschreibung im App Store gibt es zusätzlich auf Französisch, Arabisch, Türkisch und Persisch. Für Arabisch und Persisch wird die Oberfläche von rechts nach links dargestellt; die Karten der Bibliothek verwenden dafür logische statt fester Positionen. Persisch erscheint in Nextclouds Sprachauswahl als „فارسی“ und wird dort wie alle anderen Sprachen ausgewählt.

### Geändert
- Bibliothek: Suche, Sortierung, Filter und die Auswahlleiste bleiben beim Scrollen oben sichtbar. „Auswahl bearbeiten“ ist so auch in langen Listen ohne Zurückscrollen erreichbar.

## 0.10.0 – 2026-10-08

### Hinzugefügt
- **Navigation neu geordnet:** Alle Bücher, Weiterlesen, Ungelesen, Gelesen, **Serien**, **Geteilt**, **Ordner**, danach die Regale. „Serien“ zeigt direkt alle Serien (Klick öffnet die Bände) und ist kein Filter-Eintrag mehr; der Schalter „Serien gruppieren“ entfällt.
- **Ansicht „Geteilt“:** alle geteilten Bücher als Raster oder Liste mit Endlos-Scrollen, eingrenzbar auf „Mit mir geteilt“ / „Von mir geteilt“; gefiltert wird in der Datenbank, damit es auch bei sehr großen (Community-)Bibliotheken schnell bleibt. Die Freigaben-Übersicht ist über „Freigaben verwalten“ erreichbar.
- **Ordneransicht:** Bücher nach Ordnerstruktur durchsuchen (Pfadleiste, Unterordner mit Anzahl, optional inklusive Unterordnern), Ordner teilen und in der Dateien-App öffnen.
- **Serien teilen:** live und nur lesend – später zur Serie hinzukommende Bände werden beim nächsten Abgleich (alle 15 Minuten) automatisch mitgeteilt.
- **Ordner teilen:** ein Ordner der Bibliothek wird als *eine* schreibgeschützte Nextcloud-Freigabe geteilt (nicht eine Freigabe pro Buch).
- **Teilen-Symbol** auf Büchern, Serien und Ordnern, die du teilst oder die mit dir geteilt wurden (unterschiedliche Symbole und Tooltips).
- **Einstellung „Begleitdateien speichern“:** wie bisher als versteckte Datei neben dem Buch (`.<Buch>.opf`) oder gesammelt in einem versteckten `.meta`-Ordner pro Verzeichnis (`.meta/<Buch>.opf`) – übersichtlicher z. B. im Windows-Explorer über den Sync-Client. Beim Umstellen verschiebt ein Hintergrundjob die vorhandenen eigenen Begleitdateien; gelesen werden immer beide Orte, leere `.meta`-Ordner werden entfernt.
- API: `GET /books` kennt `shared=incoming|outgoing|any`, `folder` und `folderRecursive`; das Buch-JSON hat `sharedOut`; neue Endpunkte `GET /folders`, `POST/DELETE /series/shares`, `POST/DELETE /folders/shares`; `GET /series` liefert `sharedWith`/`shared`; `GET /shares` listet Serien- und Ordnerfreigaben (`type: series|folder`); Einstellung `sidecarLocation`; Capabilities melden `features` (`shared-filter`, `series-shares`, `folder-shares`, `folders`, `sidecar-meta`). Neue Tabellen `ebookreader_series_shares`, `ebookreader_folder_shares` und Spalte `books.shared_owner` (Migration `Version1008Date20261008100000`).

### Geändert
- **Geteilte Ordner erscheinen automatisch in der Bibliothek:** Bücher in Ordnern, die andere Benutzer geteilt haben (über die App oder ganz normal in der Dateien-App), werden indexiert – egal, wo die Freigabe eingebunden ist, auch außerhalb der Bibliotheksordner. Liegt die Freigabe in einem Bibliotheksordner, gibt es keine Duplikate. Lesestatus, Fortschritt und Markierungen bleiben pro Benutzer; Dateien des Eigentümers werden weiterhin nie verändert.
- Release-Workflow: Die Veröffentlichung im Nextcloud App Store läuft nur noch, wenn die Repository-Variable `APPSTORE_PUBLISH` auf `true` steht. Solange die App dort nicht registriert ist, schlägt das Release dadurch nicht mehr fehl; das GitHub-Release wird wie bisher erstellt.

### Behoben
- Beim Kopieren eines Buchs in der Dateien-App (oder per WebDAV COPY) wird die Begleitdatei jetzt mitkopiert. Verschieben, Umbenennen, Löschen, Organisieren und Konvertieren behandeln beide Ablageorte der Begleitdateien.
- Delta-Sync (`GET /sync`): Änderungen an Freigaben (Buch, Regal, Serie oder Ordner geteilt bzw. nicht mehr geteilt, Freigabe in der Dateien-App gelöscht, Empfänger gelöscht) setzen jetzt `updated_at` der betroffenen Bücher des Eigentümers neu. Die Android-App erhält so den neuen Wert von `sharedOut` im nächsten Abgleich und braucht dafür keinen vollständigen Neuabgleich mehr.

## 0.9.0 – 2026-10-07

### Geändert
- Kontaktadresse der App (App-Store-Angaben in `info.xml`, `composer.json`) ist jetzt it@wasmitleder.de.
- `.gitignore` schließt Schlüssel- und Umgebungsdateien aus (`*.key`, `*.pem`, `*.p12`, `.env`), damit z. B. der App-Store-Signaturschlüssel nie versehentlich committet wird.

### Behoben
- Geteilte Bücher: Löschen, Sortieren, Umbenennen und „Original löschen“ nach der Comic-Konvertierung veränderten bisher die Datei des Eigentümers, wenn die Freigabe Löschrechte hatte. Die App rührt Dateien anderer Benutzer nicht mehr an: `DELETE /books/{fileId}` antwortet mit 403 („The book belongs to <Benutzer>; remove the share instead“), `POST /books/delete` meldet solche Bücher als fehlgeschlagen (`error: shared`), „Ordnen“ überspringt sie mit Hinweis und räumt keine leeren Ordner innerhalb einer Freigabe (auch nicht deren Wurzel) mehr weg. Der Lösch-Dialog zeigt geteilte Bücher mit „geteilt von …“ an und löscht nur eigene. Das Buch-JSON hat dafür die neuen Felder `owner` (Benutzer-ID des Dateieigentümers) und `shared` (Datei stammt aus einer Freigabe).
- Geteilter Ordner mit Bearbeitungsrecht: Bearbeiten Eigentümer und Empfänger die Metadaten eines Buchs, überschreiben sie sich nicht mehr gegenseitig. Vor dem Schreiben der Begleitdatei (`.<Buch>.opf`) wird geprüft, ob sie sich seit dem Aufbau der eigenen Bibliothekszeile geändert hat; dann werden zuerst die fremden Änderungen übernommen (nicht bearbeitete Felder behalten die Werte der anderen Person) und ein Schreiben mitten in einer fremden Änderung wird wiederholt. Bleibt die Begleitdatei dauerhaft in Bewegung, wird die Änderung nur in der Bibliothek gespeichert und eine Warnung gezeigt. Nach jedem Schreiben von Begleitdatei oder Datei werden die Bücher aller Benutzer sofort neu eingelesen, statt erst beim nächsten Scan (bis zu 6 Stunden).
- Vom Besitzer geteilte Bücher (App-Teilen): Titel, Serie usw., die der Empfänger ändert, bleiben jetzt erhalten. Sie werden immer als eigene Überschreibungen in der Bibliothek des Empfängers gespeichert (nie in Begleitdatei oder Datei des Besitzers) und haben Vorrang vor den Werten des Besitzers; „Metadaten in die Datei schreiben“ ist für solche Bücher gesperrt.
- Persönliche (nur in der App gespeicherte) Tags landen nicht mehr in der Begleitdatei oder in der Buchdatei: Die Tags eines Benutzers erscheinen nicht mehr beim anderen, und das Entfernen eines Tags des Eigentümers wirkt nicht mehr bei ihm. Beim App-Teilen erhält der Empfänger nur Genres und Datei-Tags des Besitzers, nie dessen persönliche Tags.
- Konvertieren/Optimieren in einem geteilten Ordner mit „Original löschen“: Status, Bewertung, Tags, Lesefortschritt und Markierungen werden jetzt für alle Benutzer übernommen, die das Original in ihrer Bibliothek hatten, und die neue Datei wird für sie sofort indexiert (bisher nur für den ausführenden Benutzer; bei den anderen blieben Fortschritt und Markierungen am gelöschten Original und wurden nach 30 Tagen entfernt).
- Markierungen und Notizen eines Empfängers bleiben erhalten, wenn eine Freigabe widerrufen wird, ein Buch ein geteiltes Smart-Regal verlässt oder ein Mount verschwindet (wie der Lesefortschritt). Die Bereinigung löscht Markierungen nur noch, wenn die Datei selbst gelöscht wurde.
- Freigegebene Bücher: Bewertungs-, Status- und Lesefortschrittsänderungen des Besitzers lösen beim Empfänger keine Neuindexierung mehr aus und verraten nicht mehr dessen Aktivitätszeiten. Neue Spalte `meta_updated_at` in `ebookreader_books` (Migration `Version1007Date20261007100000`) für Metadaten-, Cover- und Dateiänderungen; `updatedAt` für `/sync` bleibt unverändert.
- Nach dem Bearbeiten eines EPUB werden auch die Positionen der Markierungen aller Benutzer auf die geänderten Kapitel umgeschrieben (wie die Lesepositionen).

## 0.8.1 – 2026-10-07

### Behoben
- `GET /books` und `/series`: Der OCS-Parameter `format=json` (Antwortformat) wurde als Buchformat-Filter gelesen und lieferte deshalb leere Listen, z. B. leere Regale in der Android-App. Die Werte `json` und `xml` werden jetzt ignoriert.

## 0.8.0 – 2026-10-06

### Hinzugefügt
- Capabilities melden die installierte App-Version (`ebookreader.version`), damit Clients wie die Android-App prüfen können, welche Funktionen der Server bietet, und bei zu alten Server-Versionen einen Hinweis zeigen.
- **Status laufend/abgeschlossen** pro Buch und Comic: In den Buchdetails und in „Ausgewählte bearbeiten“ lässt sich festlegen, ob ein Werk noch fortgesetzt wird (laufend) oder abgeschlossen ist; ohne Angabe gilt „unbekannt“. Der Status wird nur in der App gespeichert (nicht in die Datei geschrieben), erscheint als kleines Label auf der Karte und in der Liste und ist filterbar: Navigationsgruppe „Completion status“ mit Anzahl, Filter `completion:ongoing|completed|unknown` (auch in der URL und in intelligenten Regalen).
- **Altersfreigabe** (optional, Stufen 0, 6, 12, 16, 18): Beim Einlesen wird sie aus ComicInfo.xml (`AgeRating`, z. B. „Everyone“ → 0, „Teen“ → 12, „Mature 17+“ → 18) bzw. aus EPUB 3 (`schema:typicalAgeRange`) übernommen; Altersangaben ohne passende Stufe werden auf die nächsthöhere Stufe aufgerundet, unbekannte Werte ignoriert. Von Hand gesetzte Werte (auch „keine Altersfreigabe“) haben Vorrang und überstehen ein erneutes Einlesen, „Use value from file“ nimmt wieder den Wert aus der Datei. Anzeige als Badge „16+“ auf dem Cover, Bearbeiten in den Details und in der Mehrfachauswahl, Filter in der Navigation („Up to 12“, einzelne Stufen, „No age rating“) bzw. `age:<=12`, `age:16`, `age:none`.
- **Serie fortsetzen:** Ist der zuletzt gelesene Band einer Serie fertig, zeigt „Weiterlesen“ den nächsten noch nicht begonnenen Band (Label „Next volume“). Am Ende eines Buchs (ab 98 %) bietet der Reader unaufdringlich „Continue with Volume n: Titel“ an, und die Details eines gelesenen Bands haben einen Button zum nächsten Band. Reihenfolge: Bandnummer, ohne Nummer nach Titel (natürliche Sortierung); weitere Ausgaben desselben Bands (gleiche Nummer) werden übersprungen.
- API (auch für die Android-App, Details in `docs/CONTRACTS-v4.md`, Abschnitt 5): Buch-JSON mit `completion`, `ageRating` und `ageRatingManual` (auch in `GET /api/v1/sync`); `PATCH /api/v1/books/{fileId}/app-data` nimmt `completion`, `ageRating` (explizites `null` = keine Angabe bzw. von Hand „keine Freigabe“) und `resetAgeRating`, jede Änderung setzt `updatedAt` neu. Neu: `PATCH /api/v1/books/app-data` für bis zu 500 Bücher, `GET /api/v1/books/{fileId}/next` (nächster Band oder `null`), `GET /api/v1/progress/recent` liefert zusätzlich `upNext`, `GET /api/v1/facets` die Zähler `completion` und `ageRatings`. Neue Spalten in `ebookreader_books` (Migration `Version1006`), beim Konvertieren werden Status und eine von Hand gesetzte Altersfreigabe übernommen.
- **Teilen** von Büchern und Regalen mit anderen Nextcloud-Benutzern, nur lesend. „Teilen…“ in den Buchdetails und im Regal-Menü öffnet einen Dialog mit Benutzersuche (die Suche der Dateien-App, sie beachtet die Admin-Einstellungen) und der Liste der Empfänger mit Entfernen-Knopf. Ein geteiltes Buch ist eine normale, nur lesbare Nextcloud-Freigabe der Datei (ohne E-Mail), daher gelten alle Freigabe-Einstellungen des Servers (Teilen aus, ausgeschlossene Gruppen, „nur mit Gruppenmitgliedern“, Weiterteilen, Teilen-Recht der Datei); verweigert Nextcloud die Freigabe, erscheint der Grund als Meldung. Jeder behält seinen eigenen Lesefortschritt, seine Bewertung, seinen Status und seine Markierungen; Empfänger sehen davon beim Besitzer nichts, wohl aber dessen Metadaten des Buchs (Titel, Autoren, Serie, Beschreibung, Genres, Tags aus Datei oder Begleitdatei).
- **Geteilte Regale sind live:** Der Empfänger sieht das Regal in seiner Regalliste (Symbol, „Geteilt von …“, nur lesend; Ändern ergibt `403`). Bücher, die ins manuelle Regal kommen oder es verlassen, werden sofort mit- bzw. nicht mehr geteilt; intelligente Regale gleichen sich nach einer Filteränderung und alle 15 Minuten ab (neuer Hintergrundjob `SyncSharedShelvesJob`). Höchstens 50 Empfänger pro Regal und 1000 Bücher pro geteiltem Regal. Wird das Regal gelöscht oder nicht mehr geteilt, entfernt die App ihre Freigaben, außer eine andere Freigabe der App braucht die Datei noch. Freigaben, die der Benutzer selbst in Dateien angelegt hat, werden mitbenutzt und nie gelöscht; eine in Dateien entfernte Freigabe legt der Abgleich nicht wieder an.
- Geteilte Bücher erscheinen in der Bibliothek des Empfängers, egal wo Nextcloud sie einhängt (Freigabe-Ordner), auch außerhalb der Bibliotheksordner. Sie werden im Hintergrund, beim Öffnen der Bibliothek und beim Scannen eingelesen; ist die Annahme von Freigaben aktiviert, nach dem Annehmen.
- Neuer Navigationseintrag **„Geteilt“**: zeigt, was ich mit wem teile und was mit mir geteilt ist, jeweils mit Entfernen-Knopf (Empfänger können geteilte Bücher und Regale auch selbst entfernen).
- API: `GET /api/v1/shares`, `POST/DELETE /api/v1/books/{fileId}/shares`, `POST/DELETE /api/v1/shelves/{id}/shares`; das Regal-JSON hat die neuen Felder `owner`, `ownerDisplayName`, `readOnly` und `shareCount`, `GET /shelves` liefert mit mir geteilte Regale nach den eigenen, der Filter `shelf:<id>` funktioniert auch für sie. Capabilities melden `sharing: true`. Neue Tabellen `ebookreader_shelf_shares` und `ebookreader_file_shares` (Migration `Version1006Date20261005140000`). Details in `docs/CONTRACTS-v5.md`, Sicherheitsmodell in `docs/SECURITY-SHARING.md`.
- **Übersetzungen**: Deutsch (du und Sie), Spanisch, Japanisch. Die ganze Weboberfläche (Bibliothek, Reader, Editor, Konvertieren, Einstellungen, Dateien-Aktionen), das Dashboard-Widget „Weiterlesen“, die Titel und Beschreibungen des OPDS-Katalogs, der Eintrag in der Navigation sowie Name, Kurzbeschreibung und Beschreibung im App Store. Nextcloud wählt die Sprache nach der Benutzereinstellung: „Deutsch (Persönlich: Du)“ nutzt `de`, „Deutsch (Förmlich: Sie)“ `de_DE`; ohne passende Übersetzung bleibt es Englisch. Meldungen, die der Server als Fehlertext liefert, sind weiterhin englisch.
- Werkzeug für Übersetzungen: `npm run l10n:extract` sammelt alle Texte aus `src/`, `lib/` und `appinfo/info.xml` in `translationfiles/source.json` und erzeugt `l10n/<lang>.js` aus `l10n/<lang>.json`, `npm run l10n:check` prüft Platzhalter (`{name}`, `%s`, `%n`), Pluralformen und listet fehlende und veraltete Texte je Sprache auf, `npm run l10n:missing <lang>` gibt die fehlenden Texte als JSON aus. Die CI bricht nur bei kaputten Dateien und falschen Platzhaltern ab, fehlende Übersetzungen sind Warnungen (siehe CONTRIBUTING.md).

### Behoben
- Browser-Tab der Bibliothek zeigte „E-book library - [object Object]“ (Fehler in @nextcloud/vue 9.13, der App-Name wurde als Objekt angehängt); der Titel lautet jetzt „E-book library - <App-Name> - <Instanz>“.
- Der Menüpunkt „Optimize images…“ der Mehrfachauswahl zeigte statt der Auslassungspunkte ein Ersatzzeichen (�).

## 0.7.0 – 2026-10-05

### Hinzugefügt
- **Vollbildmodus** im Reader (Web): neuer Button „Vollbild“/„Vollbild beenden“ in der Leiste und die Taste `F` (nicht beim Tippen in Feldern oder Dialogen). Esc beendet das Vollbild wie gewohnt, ohne das Buch zu schließen; beim Schließen des Readers endet es automatisch. Vollbild gilt für die ganze Seite, die Nextcloud-Kopfzeile wird dabei ausgeblendet, sodass Inhaltsverzeichnis, Einstellungen, Markierungs-Popups und Dialoge sichtbar bleiben. Funktioniert auch im Dateien-Viewer und in Safari/iPadOS (webkit-Variante); wo der Browser kein Vollbild erlaubt (z. B. Safari auf dem iPhone), erscheint der Button nicht.

### Geändert
- Lesestatus und Lesefortschritt hängen jetzt in beide Richtungen zusammen. Gelesen (`finished`) setzt den Fortschritt auf 100 %, Ungelesen (`unread`) auf 0 % (das Buch öffnet wieder am Anfang), Lese gerade (`reading`) lässt ihn unverändert. Umgekehrt setzt ein gespeicherter Fortschritt den Status: ab 98 % `finished`, bei 0 % `unread`, dazwischen `reading`; das gilt jetzt auch, wenn der Status vorher von Hand gesetzt war (Ausnahme: ein von Hand gesetztes `reading` bleibt bei 0 % stehen). Die Bibliothek zeigt den neuen Prozentwert sofort, ein als ungelesen markiertes Buch verschwindet aus „Weiterlesen“.
- API: `PATCH /api/v1/books/{fileId}/app-data` mit `readStatus` schreibt den Fortschritt mit `clientUpdatedAt` = Serverzeit (gewinnt also gegen ältere Positionen anderer Geräte und kommt über `GET /api/v1/sync` an); der Locator enthält dann nur die Gesamtposition (`href: ""`, `totalProgression` 0 bzw. 1). `PUT /api/v1/progress/{fileId}` und `POST /api/v1/progress/batch` akzeptieren deshalb `href: ""`, wenn `locations.totalProgression` gesetzt ist. `GET /api/v1/progress/recent` lässt Bücher bei 0 % weg. Der Reader speichert die Position beim Schließen, bevor die Bibliothek neu lädt.

### Behoben
- Echte RAR-Comics (CBR) ohne Cover, die sich nicht öffnen ließen, obwohl 7-Zip auf dem Server installiert ist: Manche 7-Zip-Builds (p7zip ohne `p7zip-rar`, 7-Zip-Pakete ohne den unfreien RAR-Codec) können ein RAR zwar auflisten, aber nicht entpacken („Unsupported Method“). Die Seitenliste kam dann vom Server, jede Seite und das Cover scheiterten, und der Reader wich nicht auf das Entpacken im Browser aus. Jetzt versucht der Server beim Entpacken die übrigen installierten Programme (`unrar`, `bsdtar`), und lässt sich die erste Seite gar nicht entpacken, lehnt er die Seitenliste ab, sodass der Reader die Datei im Browser öffnet (und dort das Cover erzeugt). Die Fehlermeldung im Log nennt jetzt die Ausgabe des Programms und die Lösung (`unrar` oder `bsdtar` aus `libarchive-tools` installieren).

## 0.6.1 – 2026-10-02

### Hinzugefügt
- **Bilder optimieren** für Comics (optional, verlustbehaftet): Im Konvertieren-Dialog verkleinert „Bilder optimieren“ die Seitenbilder auf höchstens 2560 px (Tablet und Monitor) oder 1920 px Höhe (Handy und E-Ink), auf Wunsch werden PNG-Seiten ohne Transparenz zu JPEG (Qualität 85). Das Seitenverhältnis bleibt, es wird nie hochskaliert, Seiten innerhalb der Grenze und Formate, die GD nicht sicher verarbeitet (GIF, WebP, AVIF), werden unverändert übernommen, ebenso jede Seite, die nach dem Neukodieren nicht kleiner wäre. EXIF-Daten der neu kodierten Seiten entfallen. Dazu eine Größenschätzung („ca. 180 MB → 65 MB, 37 von 52 Seiten werden optimiert“), die nur Bildköpfe liest und höchstens drei Seiten wirklich neu kodiert (`GET /api/v1/books/{fileId}/convert/estimate`). Das Zielformat darf das aktuelle Format sein („Nur optimieren“, die Datei heißt dann „Name (optimized).cbz“); Bewertung, Status, App-Tags, Sidecar und Leseposition wandern wie bei jeder Konvertierung mit. Das Optimieren läuft immer als Hintergrund-Task mit Fortschritt („Optimizing page 3 of 52“), nur auf dem Server (CBR braucht dafür `bsdtar` oder `unrar`, GD mit JPEG-Unterstützung wird vorausgesetzt). Das Original kommt auf Wunsch in den Papierkorb und lässt sich von dort wiederherstellen.
- Mehrfachauswahl: neue Aktion „Bilder optimieren…“ startet für alle markierten Comics je einen Task (`POST /api/v1/convert/optimize`, höchstens 100 Bücher; die Tasks laufen nacheinander). `POST /api/v1/books/{fileId}/convert` nimmt dafür das optionale Objekt `optimize` (`maxHeight` 0/2560/1920, `jpegQuality` 70 bis 95, `pngToJpeg`) an, `GET /api/v1/convert/capabilities` meldet `optimize.available`.
- `occ ebookreader:scan --force` liest auch unveränderte Bücher neu ein, optional nur bestimmte Formate (`--format=cbr --format=cb7`). Nützlich, nachdem ein Archiv-Programm wie `bsdtar` installiert wurde: Bisher blieben Cover und Metadaten von CBRs leer, bis sich die Datei änderte.

### Geändert
- Comic-Cover: Ist die erste Seite ein breiter Titel-Banner oder eine Doppelseite, nimmt die App die erste Seite im Hochformat unter den ersten vier Seiten als Cover (statt die Mitte des Banners auszuschneiden). Eine in ComicInfo.xml als `FrontCover` markierte Seite gilt weiterhin immer. Bereits eingelesene Comics bekommen das neue Cover mit `occ ebookreader:scan <user> --force --format=cbz`.

### Behoben
- Comic-Archive werden nach ihrem Inhalt statt nach der Dateiendung gelesen: Eine `.cbr`, die eigentlich ein ZIP ist (häufig), wird jetzt ohne Zusatzprogramm direkt in PHP gelesen; ebenso `.cbz`-Dateien, die in Wahrheit RAR oder 7z sind (dann über das Archiv-Programm). Vorher scheiterten Cover und Metadaten mit „sevenZip exited with 2“.
- Konvertieren im Browser (z. B. CBR → CBZ ohne RAR-fähiges Programm auf dem Server) lädt das Ergebnis jetzt in Teilstücken hoch (Nextcloud-Chunking), wie der normale Upload. Ein großes Ergebnis (200 MB) in einem einzigen Request wurde sonst von Proxy- oder Zeitlimits abgebrochen („Erwartete Dateigröße … aber … gelesen“). Gilt auch für „In CBZ umwandeln“ im Editor.
- Kann bei einer echten RAR-Datei nur 7-Zip ohne RAR-Unterstützung genutzt werden (z. B. das `7zip`-Paket von Alpine/AIO), nennt die Fehlermeldung jetzt die Lösung: `libarchive-tools` (bsdtar) oder `unrar` installieren.

### Dokumentation
- README auf Englisch neu strukturiert (Voraussetzungen, Installation, Funktionen, Metadaten, OPDS, Administration, Datenablage, Sicherheitsmodell); die deutsche Fassung liegt unter `docs/translations/README.de.md`. Neu: `CONTRIBUTING.md` und `SECURITY.md`.

## 0.6.0 – 2026-10-02

### Hinzugefügt
- **Markierungen, Notizen und Lesezeichen** im Reader: Text in EPUB, MOBI, AZW3 und FB2 markieren und aus fünf Farben wählen, eine Notiz dazu schreiben oder den Text kopieren. Ein Klick auf eine Markierung öffnet sie zum Ändern (Farbe, Notiz, Löschen). Der Lesezeichen-Button in der Leiste markiert die aktuelle Seite, auch bei Comics (Seitenindex). Das neue Panel „Markierungen & Lesezeichen“ (Tab neben dem Inhaltsverzeichnis) listet alles nach Typ und Position, springt zur Stelle, bearbeitet Notizen und exportiert alles als Markdown-Datei (im Browser erzeugt). Markierungen werden als SVG-Overlay gezeichnet, Notiztexte erscheinen nur als Text und nie im Buch-HTML. Beim Anlegen, Ändern und Löschen aktualisiert sich die Oberfläche sofort, Fehler erscheinen als Hinweis.
- **Annotations-API** für weitere Clients (z. B. die Android-App): `GET/POST /api/v1/books/{fileId}/annotations`, `PATCH/DELETE /api/v1/annotations/{uuid}`. Die UUID erzeugt der Client (Anlegen auch offline), der Server nimmt sie als Upsert an. Last-write-wins über `clientUpdatedAt` (älterer Stand: `409` mit dem aktuellen Eintrag), Löschen setzt einen Tombstone. `GET /api/v1/sync` liefert zusätzlich `annotations` (inklusive Tombstones, eigener Cursor-Anteil), die Capabilities melden `annotations: true`. Neue Tabelle `ebookreader_annotations` (Migration `Version1005`); beim Löschen eines Benutzers oder eines Buchs werden die Einträge entfernt, Tombstones nach 90 Tagen. Download-gesperrte Freigaben liefern keine Markierungen. Details in `docs/CONTRACTS-v4.md`.
- **OPDS-Katalog** (OPDS 1.2) für E-Reader-Apps wie KOReader, Moon+ Reader, Librera, Thorium oder Panels: Navigation nach Neu hinzugefügt, Weiterlesen, Alle Bücher, Autoren, Serien, Genres, Tags und Regalen (auch intelligente Regale), Suche (OpenSearch), Seiten zu 50 Büchern, Cover, Metadaten und Download mit Content-Length und Range-Unterstützung. Anmeldung per HTTP Basic mit einem App-Passwort unter `/apps/ebookreader/opds` (ohne gültige Anmeldung `401` mit `WWW-Authenticate`, mit Brute-Force-Schutz und Rate-Limits). Standardmäßig aus: jeder Benutzer schaltet ihn in den App-Einstellungen selbst ein (mit Katalog-URL zum Kopieren), Administratoren können ihn serverweit sperren (`opds_enabled`). Es sind nur Bücher der eigenen Bibliothek abrufbar, Dateien aus Freigaben ohne Download-Recht werden nicht ausgeliefert. Neuer Endpunkt `GET/PUT /api/v1/opds` für die Schalter.
- **Dashboard-Widget „Weiterlesen“:** zeigt die angefangenen Bücher (zuletzt gelesen zuerst, bis zu 7) mit Cover, Autor und Fortschritt, aktualisiert sich selbst und bietet einen Button zur Bibliothek.
- Bücher mit fehlenden Metadaten finden: neuer Filter `missing:<Feld>` (Genre, Tags, Autor, Serie, Beschreibung, Cover, Sprache). In der Navigation zeigt die Gruppe „Nachpflegen“ („Needs attention“) die Felder mit Anzahl der betroffenen Bücher (Einträge mit 0 werden ausgeblendet). Ein Klick schaltet wie bei anderen Filtern zwischen enthalten, ausgeschlossen und aus um; Chips heißen z. B. „Ohne Genre“ bzw. „Hat Genre“. Funktioniert in Bibliothek, Serien und Smart-Regalen, mit „alle/beliebige“ und in der URL. `GET /facets` liefert dazu `missing` mit den Zählern.

### Geändert
- Gelesene Bücher werden in der Bibliothek standardmäßig ausgeblendet. Ein Schalter in der Werkzeugleiste („Gelesene ausblenden“) blendet sie wieder ein und wird im Browser gemerkt. Der Status-Filter „Gelesen“ zeigt sie weiterhin. Neuer Parameter `hideFinished=1` für `GET /books` und `GET /series`.

### Behoben
- „Weiterlesen“ zeigte auch Bücher, die bereits als gelesen markiert waren. Sie verschwinden jetzt sofort nach dem Markieren aus der Leiste.

### Dokumentation
- README für das öffentliche Repository überarbeitet: interne Planungsdetails entfernt, Funktionen und Einstellungen aktualisiert, Beta-Hinweis statt Alpha-Warnung (im Produktiveinsatz erprobt).
- Neue Anleitung „Archiv-Programme installieren (7-Zip)“: eigenes Image auf Basis des offiziellen Docker-Images und Nextcloud All-in-One über `NEXTCLOUD_ADDITIONAL_APKS`.
- Neu: `docs/RELEASING.md` (Ablauf für Releases und den App Store).

## 0.5.1 – 2026-10-01

### Behoben
- Nach einer Konvertierung im Browser (z. B. CBR ohne `7z` auf dem Server) blieb das Original liegen, und das neue Buch erschien erst Minuten später. Grund: Große Dateien werden im Hintergrund indexiert, der Dialog wartete aber nur wenige Sekunden. Jetzt übernimmt der Server den Abschluss sofort, unabhängig von der Dateigröße: Er indexiert das neue Buch, kopiert die Begleitdatei, übernimmt Bewertung, Lesestatus, App-Tags und Leseposition und löscht danach das Original, wenn gewünscht.
- Der Konvertieren-Dialog merkt sich, ob das Original gelöscht werden soll.

## 0.5.0 – 2026-10-01

### Hinzugefügt
- **Begleitdateien** (wie `.nfo` bei Kodi): Metadaten-Änderungen landen standardmäßig in einer kleinen versteckten Datei `.<Buchdatei>.opf` neben dem Buch (Calibre-kompatibles OPF 2.0 mit Titel, Autoren, Beschreibung, Sprache, Verlag, Datum, ISBN, Genres, Tags, Serie und Band). Das geht schnell, funktioniert für alle Formate inklusive MOBI, AZW3, CBR, CB7 und CBT und lässt die Buchdatei unangetastet.
- Neue Einstellung „Wo Metadaten-Änderungen gespeichert werden“ (Begleitdatei, in der Datei, beides, nur Bibliothek). „Im Hintergrund/sofort“ gilt nur noch für das Schreiben in die Buchdatei. Die frühere Einstellung „nie“ wird zu „Nur Bibliothek“.
- Rangfolge beim Einlesen: in der App geänderte Felder, dann Begleitdatei, dann eingebettete Metadaten, dann Dateiname. Eine von außen geänderte, neu angelegte oder gelöschte Begleitdatei löst das erneute Einlesen des Buchs aus.
- Umbenennen, Verschieben, Sortieren nach Muster, Konvertieren (Kopie, beim Löschen des Originals auch Löschen) und Löschen eines Buchs nehmen die Begleitdatei mit. Begleitdateien werden nie als Bücher indexiert.
- Aktion „Metadaten in die Buchdatei schreiben“ (Buchdetails, EPUB/CBZ/FB2/FBZ) und Endpunkt `POST /api/v1/books/{fileId}/metadata/embed`, bei großen Dateien als Hintergrundaufgabe. Damit sehen auch Reader wie Kobo oder KOReader die Metadaten, die nur eingebettete Werte lesen.
- Die Buchdetails zeigen „Metadaten in Begleitdatei gespeichert“, das Buch-JSON enthält `hasSidecar`.
- **Regale** (Backend): manuelle Regale und intelligente Regale (gespeicherter Filter) mit den Endpunkten `GET/POST /shelves`, `PATCH/DELETE /shelves/{id}`, `POST/DELETE /shelves/{id}/books` und `PUT /shelves/{id}/books/order`. Neuer Filterbegriff `shelf:<id>` und Sortierung `sort=shelf`. Zuordnungen verschwinden beim endgültigen Entfernen eines Buchs (Aufräumjob) und beim Löschen des Benutzers.
- **Serien** (Backend): Endpunkt `GET /series` (Name, Anzahl, gelesen, Cover, erstes Buch) und der Parameter `inSeries=0|1` für `GET /books`. `sort=series` sortiert innerhalb einer Serie nach Band.
- **Hierarchische Genres und Tags** (Backend): `tag:Fantasy/*` und `genre:Fantasy/*` treffen den Eintrag selbst und alles darunter (Groß-/Kleinschreibung egal, auch als Ausschluss). Leerzeichen um `/` werden beim Speichern entfernt, maximal 5 Ebenen.
- Neue Datenbanktabellen `ebookreader_shelves` und `ebookreader_shelf_books` (Migration `Version1004Date20261002090000`), Version 0.5.0.
- **Regale** (Oberfläche): Navigationsbereich „Regale“ mit manuellen und intelligenten Regalen (Anzahl, Filter-Symbol), Anlegen, Umbenennen, Löschen mit Bestätigung und Umsortieren per Auf/Ab. „Als intelligentes Regal speichern…“ in der Filterleiste, „Regal aktualisieren“, wenn der Filter eines intelligenten Regals geändert wurde. „Zu Regal hinzufügen…“ in den Buchdetails (Mehrfachauswahl, „Neues Regal“) und in der Auswahlleiste, dort auch „Aus Regal entfernen“. Ein manuelles Regal wird in Regalreihenfolge angezeigt.
- **Serien gruppieren**: Schalter in der Werkzeugleiste (wird im Browser gemerkt). Serienkarten mit gestapelten Covern, Bandanzahl und Lesefortschritt, darunter die Bücher ohne Serie. Ein Klick zeigt die Bände der Serie mit „Zurück zu den Serien“. Serienansicht, Regal und Filter stehen in der URL.
- **Hierarchie bei Genres und Tags**: Einträge mit `/` (z. B. `Fantasy/High Fantasy`) erscheinen als aufklappbarer Baum, auch wenn der Oberbegriff selbst nicht vergeben ist. Ein Oberbegriff filtert mit `tag:Fantasy/*` den ganzen Zweig und zeigt in der Filterleiste „Fantasy (+ sub)“. Zahlen an Oberbegriffen sind Summen und mit „≈“ markiert.
- **Hochladen**: Schaltfläche „Hochladen“ in der Navigation und im leeren Zustand sowie Drag & Drop auf die Bibliothek („Zum Hinzufügen in die Bibliothek ablegen“). Der Upload läuft über `@nextcloud/upload` mit Chunking (auch 300 bis 400 MB), nur Bucherweiterungen (epub, mobi, azw3, fb2, fbz, cbz, cbr, cb7, cbt), in den ersten Bibliotheksordner. Vorhandene Dateien werden nie überschrieben („Name (2).epub“). Fortschritt pro Datei und gesamt, Abbrechen möglich; danach werden Bibliothek und Filter neu geladen. Bei Dateien über 20 MB erscheint der Hinweis „Large files are being indexed in the background“.
- **Mehrfachauswahl bearbeiten**: „Edit selected…“ (früher „Genres und Tags bearbeiten“) öffnet den Dialog „Edit selected books“ mit den Abschnitten Autoren (ersetzen, hinzufügen, entfernen), Serie (setzen oder entfernen, Bandnummern behalten, in Listenreihenfolge oder nach Titel nummerieren mit Start und Schrittweite, Vorschau der ersten 10 Bücher), Verlag, Sprache sowie Genres und Tags. Nur abgehakte Abschnitte werden gesendet, alles andere bleibt pro Buch erhalten. Die Auswahl bleibt nach dem Speichern erhalten, Bibliothek und Filter werden neu geladen.
- Neuer Endpunkt `POST /api/v1/books/bulk-metadata` (bis zu 500 Bücher, 5 Aufrufe pro Minute). Jedes Buch läuft über den normalen Metadaten-Speicherweg (Speicherziel, Begleitdatei, Overrides, keine Änderung bei gleichem Wert); die Antwort enthält `updated`, `unchanged`, `failed` je Datei und `writeQueued`. Bei `async=1` oder bei mehr als 50 Büchern mit dem Speicherziel „In der Datei“ oder „Beides“ läuft die Änderung als Hintergrundaufgabe (Typ `bulk`, Fortschritt „Book 12 of 80“, Antwort 202 mit `taskId`).

### Geändert
- Standard für Metadaten-Änderungen ist jetzt die Begleitdatei statt der Buchdatei. Wer die Metadaten weiterhin in die Datei schreiben möchte, wählt „In der Datei“ in den Einstellungen.
- Ein vollständiges Speichern im Editor aktualisiert bei den Zielen „Begleitdatei“ und „Beides“ auch die Begleitdatei, damit sie die neuen Werte nicht überschreibt.
- Ist der Ordner oder die Freigabe schreibgeschützt, werden Änderungen nur in der Bibliothek gespeichert und mit einem Hinweis gemeldet.
- Neue Datenbankspalte `sidecar_etag` (Migration `Version1003Date20261001180000`).

### Behoben
- Tags ließen sich nicht speichern (MariaDB/MySQL: „Field 'type' doesn't have a default value“). Neue Datensätze schreiben jetzt immer alle Felder. Das betraf auch Hintergrundaufgaben beim Bearbeiten von Seiten.
- Der Hintergrundjob zum Schreiben von Metadaten brach mit „fclose(): Argument #1 must be an open stream resource“ ab. Auch das Speichern im Editor, „Als Kopie speichern“ und Konvertierungen waren betroffen.
- Meldungen („Änderungen gespeichert“ usw.) erschienen ohne Styling als Text oben links: Das Stylesheet von `@nextcloud/dialogs` wurde nicht geladen.
- Nach dem Speichern im Editor geht es zurück zur vorherigen Liste, mit Filtern, Regal und Position. Bei Warnungen erst, nachdem der Dialog geschlossen wurde. „Zurück“ verhält sich genauso.
- Genres, Tags, Autoren, Serien und Formate in der Navigation klappen auch beim Klick auf den Namen auf, nicht nur beim Klick auf den Pfeil.
- Werkzeugleiste der Bibliothek: Der Navigations-Button verdeckt das Suchfeld nicht mehr, Suche und Sortierung sind gleich hoch. Die Sortierung ist jetzt ein kompaktes Menü.
- Filter-Chips sind kompakt (einheitliche Höhe, Icons mittig), „Alle/Mindestens einer“ und „Filter zurücksetzen“ sind kleine Buttons.

## 0.3.0 – 2026-10-01

### Hinzugefügt
- Einstellung „Metadaten in Dateien schreiben“: im Hintergrund (Standard), sofort oder nie. Im Hintergrund werden Änderungen sofort in der Bibliothek gespeichert und kurz danach gesammelt in die Datei geschrieben; mehrere schnelle Änderungen ergeben nur einen Schreibvorgang.
- In der App geänderte Metadaten (Titel, Autoren, Serie, Beschreibung usw.) bleiben erhalten, wenn die Datei sich ändert oder neu eingelesen wird. Das gilt für MOBI, AZW3, CBR, CB7, CBT und für den Modus „nie“. In der Detailansicht steht „in der App geändert“ mit der Aktion „Wert aus Datei übernehmen“.
- Bücher löschen, einzeln in der Detailansicht oder für eine Auswahl, mit Bestätigungsdialog. Die Dateien landen im Nextcloud-Papierkorb und lassen sich wiederherstellen.
- Fortschrittsdialog beim Speichern im Editor: Upload-Fortschritt, Verarbeitung auf dem Server, vergangene Zeit.
- Speichern im Editor und Konvertierungen auf dem Server laufen als Hintergrundaufgabe mit echtem Fortschritt (Schritt und Fortschrittsbalken). Die Seite darf währenddessen verlassen werden, die Aufgabe läuft auf dem Server weiter.
- Die Bibliothek zeigt einen Hinweis mit Fortschritt, solange Aufgaben auf dem Server laufen, auch nach einem Neuladen der Seite.
- Vor Browser-Fallbacks, die eine große Datei (über 50 MB) vollständig herunterladen (Reader für CBR/CB7/CBT ohne Server-Seiten, Konvertierung im Browser, CBR in CBZ im Editor), erscheint eine Bestätigung.
- Lokaler Archiv-Cache (`archive_cache_mb`, Standard 2048 MB) für Bücher auf WebDAV-, SMB-, S3- oder verschlüsseltem Speicher: jede Dateiversion wird höchstens einmal kopiert und von Reader, Editor, Konvertierung und Einlesen gemeinsam genutzt. Auf lokalem, unverschlüsseltem Speicher wird gar nichts kopiert.
- Neuer Endpunkt `/apps/ebookreader/archive/{fileId}/entries` mit der Eintragsliste von EPUB, CBZ und FBZ; `/item` liefert jetzt auch FBZ und erlaubt mindestens 1200 Anfragen pro Minute.
- README-Abschnitt „Große Bibliotheken / große Dateien“: Cron, `occ background-job:worker` mit systemd-Beispiel, `archive_cache_mb`, `async_inline`, `max_edit_size_mb` und die Installation von 7z.

### Geändert
- Der Reader lädt EPUB- und FBZ-Dateien nicht mehr vollständig herunter, sondern liest nur die benötigten Einträge vom Server (mit Cache von ca. 50 MB im Browser). Schlägt das fehl, wird wie bisher die ganze Datei geladen. Der DRM-Check und die Absicherung der Kapitel bleiben unverändert.
- Das Ändern von Metadaten (z. B. ein einzelnes Tag) lädt große CBZ/EPUB/FB2-Dateien nicht mehr vollständig herunter, schreibt sie neu und lädt sie wieder hoch. Ohne tatsächliche Änderung wird gar nichts geschrieben, sonst im Hintergrund oder nach Einstellung.
- Der Editor öffnet den Metadaten-Tab sofort aus der Bibliothek, ohne die Datei zu kopieren. Seiten, Inhalt und Inhaltsverzeichnis werden erst beim Öffnen des jeweiligen Tabs geladen.
- Reine Metadaten-Änderungen im Editor behalten die Seitennamen von Comics bei und kopieren alle anderen Einträge unverändert; nur ComicInfo.xml, die OPF-Datei bzw. die FB2-Beschreibung werden ersetzt.
- Auf lokalem Speicher liest der Server Bücher direkt von der Datei, statt sie vorher in eine temporäre Datei zu kopieren.
- Das erneute Einlesen einer Datei überschreibt keine Metadaten, die noch auf das Schreiben in die Datei warten.
- Aufgaben (Speichern, Konvertieren) laufen nach der Antwort im selben PHP-Prozess (bei FPM) und zusätzlich als Hintergrundjob als Ersatz; fertige Aufgaben werden nach 24 Stunden gelöscht. Mit `async_inline=false` läuft nur der Hintergrundjob.
- Reine Metadaten-Änderungen bei CBZ und EPUB kopieren die Datei und ersetzen nur `ComicInfo.xml` bzw. die OPF-Datei; alle anderen Einträge werden roh übernommen (keine Neukomprimierung, gleiche Größe und Prüfsumme).
- Der manuelle Scan indiziert nur Dateien bis 50 MB direkt, größere Dateien laufen immer als Hintergrundjob.

### Behoben
- Beim Wechsel zwischen Büchern fuhr die Detailansicht jedes Mal neu herein und flackerte. Jetzt wird nur der Inhalt aktualisiert.
- Tag-Chips und der „Hinzufügen“-Button in der Detailansicht sind neu gestaltet: einheitliche Höhe, das × steht im Chip. Die Metadaten-Zeilen sind sauber ausgerichtet.
- Nach dem Löschen oder Umsortieren von Comic-Seiten zeigte der Editor noch die alten Seitenbilder aus dem Browser-Cache. Die Vorschau-URLs sind jetzt an die Dateiversion gebunden.
- Nach dem Speichern mit Warnungen lud der Editor den neuen Stand erst beim Bestätigen des Dialogs. Wurde der Dialog anders geschlossen, meldete das nächste Speichern fälschlich „Datei wurde geändert“. Der Editor lädt jetzt immer sofort neu.

## 0.2.0 – 2026-10-01

### Hinzugefügt
- Genres und Tags lassen sich direkt in der Detailansicht eines Buchs hinzufügen und entfernen. Ein Klick auf einen Tag filtert danach.
- Komplexe Filter: mehrere Genres, Tags, Autoren, Serien und Formate kombinierbar („alle“ oder „mindestens einer“), dazu Ausschluss-Filter. Der Filter steht in der URL und lässt sich als Lesezeichen speichern.
- Bücher organisieren: Umbenennen und Einsortieren in Ordner nach einem Muster wie `{author}/{series}/{series_index:2} - {title}`, mit Vorschau vor dem Ausführen, für ein Buch oder eine Auswahl.
- Neue Comic-Formate CB7 (7z) und CBT (tar).
- Formatkonvertierung zwischen CBZ, CB7, CBT und EPUB (Fixed Layout), mit Erklärung der Vor- und Nachteile jedes Formats. CBR kann als Ziel nicht angeboten werden, weil RAR sich nur mit proprietärer Software schreiben lässt.
  - Die Konvertierung läuft auf dem Server, wenn er Quelle und Ziel verarbeiten kann. CBZ, CBT und EPUB gehen immer, CBR und CB7 mit installiertem `7z`, `unrar` oder `bsdtar`.
  - Andernfalls konvertiert der Browser und lädt das Ergebnis hoch.
- CBR- und CB7-Comics werden ebenfalls seitenweise vom Server ausgeliefert, wenn ein Archiv-Programm installiert ist. CBT braucht dafür kein Zusatzprogramm.

### Behoben
- CBR-Comics bekommen ein Vorschaubild: serverseitig, wenn `7z`, `unrar` oder `bsdtar` installiert ist, sonst erzeugt es der Browser beim ersten Öffnen.

### Sicherheit
Die Änderungen stammen aus einem Sicherheits-Audit mit vier Schwerpunkten: Zugriffsrechte, Dateiverarbeitung, Browser, Betrieb. Einen Zugriff auf Bücher anderer Nutzer hat das Audit nicht gefunden. Details stehen in `docs/SECURITY-FIXES.md`.

**Zugriffsrechte und Freigaben**
- Freigaben mit „Download verbieten“ werden respektiert: Comic-Seiten, Buchinhalte, Editor und Konvertierung liefern keine Inhalte mehr aus. Der Reader zeigt einen Hinweis.
- Cover hochladen setzt Schreibrecht auf die Datei voraus.
- Verschieben und Umbenennen prüfen vorher Schreib- und Löschrecht.

**Auslieferung von Dateiinhalten**
- Der Endpunkt für Buchinhalte (`/item`) liefert nur noch Bilder, Fonts und Medien mit eigenem Typ. Alles andere geht als Text raus, mit strenger CSP inklusive Sandbox.
- Links in Büchern öffnen erst nach Rückfrage, nur für http, https und mailto, und ohne Zugriff des neuen Tabs auf die Nextcloud-Seite.
- Strengere CSP pro Kapitel (`script-src`, `base-uri`, `form-action`, `frame-src` und `object-src` auf `'none'`). XHTML-Kapitel mit fremdem Wurzelelement werden bereinigt.
- Buchbeschreibungen werden in der Detailansicht streng bereinigt.
- Die CSP-Erweiterung gilt nur noch für die eigenen Seiten der App sowie Files und Viewer, mit exaktem Pfadvergleich.

**Schutz vor präparierten Dateien**
- XML-Bomben (Billion Laughs, auch UTF-16-kodiert) werden abgelehnt.
- Obergrenzen für CBR/CB7: 2 GB Gesamtgröße und 5000 Seiten. Der Archivtyp wird anhand der Datei-Signatur erzwungen.
- Größenlimits für FB2, robusteres MOBI-Parsing, Begrenzung der Einträge in ZIP-Archiven.
- Riesige Bilder (über 40 Megapixel) werden nicht mehr dekodiert.
- Sehr große Kapitel lassen das Speichern im Editor nicht mehr scheitern: Ungenutzte Ressourcen werden dann behalten statt gelöscht, mit Warnung.

**Rate-Limits und Hintergrundjobs**
- Rate-Limits für Editor, Massen-Tagging (höchstens 100 Bücher), Comic-Seiten und Cover-Upload.
- Hintergrund-Scans reihen nur noch Jobs ein, höchstens 50 Nutzer pro Lauf.
- Beim Löschen eines Nutzers werden auch zwischengespeicherte Comic-Seiten entfernt.
- Die Reader-Einstellungen akzeptieren nur noch bekannte Schlüssel.

**Release-Pipeline und Abhängigkeiten**
- GitHub Actions sind auf feste Commit-Hashes gepinnt, der Release-Job läuft im Environment `appstore`, und der Signierschlüssel wird sicher aufgeräumt.
- Das App-Paket baut aus einer Liste erlaubter Dateien.
- `vitest` ist auf Version 5 aktualisiert.

## 0.1.3 – 2026-10-01

### Hinzugefügt
- CBZ-Comics werden seitenweise vom Server geladen, auf Bildschirmgröße verkleinert und serverseitig zwischengespeichert. Der Cache wird nach 30 Tagen aufgeräumt.

### Geändert
- Die Kapitel-iframes des Readers erlauben wieder Skripte, weil Chrome sonst die Bedien-Handler von foliate-js blockiert. Skripte aus Büchern bleiben blockiert: CSP pro Kapitel, geerbte Nextcloud-CSP, keine EPUB-Skriptdateien, bereinigte SVG-Kapitel.
- `GET /progress/{fileId}` antwortet bei noch nie geöffneten Büchern mit 200 und `null` statt 404.

### Behoben
- Der Reader liegt nicht mehr unter der Nextcloud-Kopfleiste. Werkzeugleiste und Fortschrittsleiste verdecken die Seite nicht mehr.
- Navigation und Seitenaufbau bei Comics funktionieren in Chrome.

## 0.1.2 – 2026-09-30

### Behoben
- Unformatierte Oberfläche: Die CSS-Dateien der App wurden nicht geladen.
- Verschachteltes Layout der Bibliothek (Navigation im Inhaltsbereich).
- „Bibliothek scannen“ indexiert sofort (bis zu 20 Sekunden pro Klick) statt nur Hintergrundjobs anzulegen. Danach lädt die Liste neu. Speichern der Einstellungen startet einen Scan.
- Bücher, die aus der Bibliothek verschwunden und wieder aufgetaucht sind, werden wieder aufgenommen.

## 0.1.1 – 2026-09-30

### Hinzugefügt
- Erste veröffentlichte Version: Bibliothek mit Genres, Tags, Suche und Filtern, Reader für EPUB, MOBI, AZW3, FB2, CBZ und CBR auf Basis von foliate-js, serverseitig synchronisierter Lesefortschritt, Editor für Metadaten, Cover, Kapitel/Seiten und Inhaltsverzeichnis (EPUB, CBZ, FB2), REST-API mit OpenAPI-Beschreibung, Integration in Files und Viewer.
- Release-Pipeline über GitHub Actions.
