const e=""+window.OC.filePath("ebookreader","","dist/libarchive-B_1yl2Td.wasm");export{e as default};
//# sourceMappingURL=libarchive-C7B-twnc.chunk.mjs.map
