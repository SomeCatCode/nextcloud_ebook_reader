import{l as e}from"./index-9dT-xvER.chunk.mjs";function i(){return e("files_sharing","isPublic",null)??document.querySelector('input#isPublic[type="hidden"][name="isPublic"][value="1"]')!==null}function l(){return e("files_sharing","sharingToken",null)??document.querySelector('input#sharingToken[type="hidden"]')?.value??null}export{l as g,i};
//# sourceMappingURL=public-VOZ0FTx2.chunk.mjs.map
