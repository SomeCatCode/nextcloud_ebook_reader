var s=class extends EventTarget{dispatchTypedEvent(t,e){return super.dispatchEvent(e)}};export{s as e};
//# sourceMappingURL=index-5Cnum8be.chunk.mjs.map
