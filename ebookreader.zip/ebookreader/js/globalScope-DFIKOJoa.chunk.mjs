const e=Object.freeze({NONE:0,READ:1,UPDATE:2,CREATE:4,WRITE:4,DELETE:8,SHARE:16,ALL:31});window._nc_files_scope??={},window._nc_files_scope.v4_0??={};const o=window._nc_files_scope.v4_0;export{e as P,o as s};
//# sourceMappingURL=globalScope-DFIKOJoa.chunk.mjs.map
