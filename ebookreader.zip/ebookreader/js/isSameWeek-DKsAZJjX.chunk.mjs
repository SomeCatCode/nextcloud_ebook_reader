import{n as c,s as n}from"./index-CRmqaJ3-.chunk.mjs";function e(r,s,o){const[t,a]=c(o?.in,r,s);return+n(t,o)==+n(a,o)}export{e as i};
//# sourceMappingURL=isSameWeek-DKsAZJjX.chunk.mjs.map
