const k=u=>u?u.replace(/[\t\n\f\r ]+/g," ").replace(/^[\t\n\f\r ]+/,"").replace(/[\t\n\f\r ]+$/,""):"",d=u=>k(u?.textContent),S={XLINK:"http://www.w3.org/1999/xlink",EPUB:"http://www.idpf.org/2007/ops"},T={XML:"application/xml",XHTML:"application/xhtml+xml"},c={strong:["strong","self"],emphasis:["em","self"],style:["span","self"],a:"anchor",strikethrough:["s","self"],sub:["sub","self"],sup:["sup","self"],code:["code","self"],image:"image"},N={tr:["tr",{th:["th",c,["colspan","rowspan","align","valign"]],td:["td",c,["colspan","rowspan","align","valign"]]},["align"]]},B={epigraph:["blockquote"],subtitle:["h2",c],"text-author":["p",c],date:["p",c],stanza:"stanza"},L={title:["header",{p:["h1",c],"empty-line":["br"]}],epigraph:["blockquote","self"],image:"image",annotation:["aside"],section:["section","self"],p:["p",c],poem:["blockquote",B],subtitle:["h2",c],cite:["blockquote","self"],"empty-line":["br"],table:["table",N],"text-author":["p",c]};B.epigraph.push(L);const $={image:"image",title:["section",{p:["h1",c],"empty-line":["br"]}],epigraph:["section",L],section:["section",L]};class z{constructor(e){this.fb2=e,this.doc=document.implementation.createDocument(S.XHTML,"html"),this.bins=new Map(Array.from(this.fb2.getElementsByTagName("binary"),n=>[n.id,n]))}getImageSrc(e){const n=e.getAttributeNS(S.XLINK,"href");if(!n)return"data:,";const[,a]=n.split("#");if(!a)return n;const s=this.bins.get(a);return s?`data:${s.getAttribute("content-type")};base64,${s.textContent}`:n}image(e){const n=this.doc.createElement("img");return n.alt=e.getAttribute("alt"),n.title=e.getAttribute("title"),n.setAttribute("src",this.getImageSrc(e)),n}anchor(e){const n=this.convert(e,{a:["a",c]});return n.setAttribute("href",e.getAttributeNS(S.XLINK,"href")),e.getAttribute("type")==="note"&&n.setAttributeNS(S.EPUB,"epub:type","noteref"),n}stanza(e){const n=this.convert(e,{stanza:["p",{title:["header",{p:["strong",c],"empty-line":["br"]}],subtitle:["p",c]}]});for(const a of e.children)a.nodeName==="v"&&(n.append(this.doc.createTextNode(a.textContent)),n.append(this.doc.createElement("br")));return n}convert(e,n){if(e.nodeType===3)return this.doc.createTextNode(e.textContent);if(e.nodeType===4)return this.doc.createCDATASection(e.textContent);if(e.nodeType===8)return this.doc.createComment(e.textContent);const a=n?.[e.nodeName];if(!a)return null;if(typeof a=="string")return this[a](e);const[s,p,m]=a,g=this.doc.createElement(s);if(e.id&&(g.id=e.id),g.classList.add(e.nodeName),Array.isArray(m))for(const f of m){const A=e.getAttribute(f);A&&g.setAttribute(f,A)}const w=p==="self"?n:p;let y=e.firstChild;for(;y;){const f=this.convert(y,w);f&&g.append(f),y=y.nextSibling}return g}}const X=async u=>{const e=await u.arrayBuffer(),n=new TextDecoder("utf-8").decode(e),a=new DOMParser,s=a.parseFromString(n,T.XML),p=s.xmlEncoding||n.match(/^<\?xml\s+version\s*=\s*["']1.\d+"\s+encoding\s*=\s*["']([A-Za-z0-9._-]*)["']/)?.[1];if(p&&p.toLowerCase()!=="utf-8"){const m=new TextDecoder(p).decode(e);return a.parseFromString(m,T.XML)}return s},D=URL.createObjectURL(new Blob([`
@namespace epub "http://www.idpf.org/2007/ops";
body > img, section > img {
    display: block;
    margin: auto;
}
.title h1 {
    text-align: center;
}
body > section > .title, body.notesBodyType > .title {
    margin: 3em 0;
}
body.notesBodyType > section .title h1 {
    text-align: start;
}
body.notesBodyType > section .title {
    margin: 1em 0;
}
p {
    text-indent: 1em;
    margin: 0;
}
:not(p) + p, p:first-child {
    text-indent: 0;
}
.poem p {
    text-indent: 0;
    margin: 1em 0;
}
.text-author, .date {
    text-align: end;
}
.text-author:before {
    content: "—";
}
table {
    border-collapse: collapse;
}
td, th {
    padding: .25em;
}
a[epub|type~="noteref"] {
    font-size: .75em;
    vertical-align: super;
}
body:not(.notesBodyType) > .title, body:not(.notesBodyType) > .epigraph {
    margin: 3em 0;
}
`],{type:"text/css"})),E=u=>`<?xml version="1.0" encoding="utf-8"?>
<html xmlns="http://www.w3.org/1999/xhtml">
    <head><link href="${D}" rel="stylesheet" type="text/css"/></head>
    <body>${u}</body>
</html>`,q="data-foliate-id",j=async u=>{const e={},n=await X(u),a=new z(n),s=t=>n.querySelector(t),p=t=>[...n.querySelectorAll(t)],m=t=>{const r=d(t.querySelector("nickname"));if(r)return r;const o=d(t.querySelector("first-name")),i=d(t.querySelector("middle-name")),l=d(t.querySelector("last-name")),h=[o,i,l].filter(b=>b).join(" "),x=l?[l,[o,i].filter(b=>b).join(" ")].join(", "):null;return{name:h,sortAs:x}},g=t=>t?.getAttribute("value")??d(t),w=s("title-info annotation");if(e.metadata={title:d(s("title-info book-title")),identifier:d(s("document-info id")),language:d(s("title-info lang")),author:p("title-info author").map(m),translator:p("title-info translator").map(m),contributor:p("document-info author").map(m).concat(p("document-info program-used").map(d)).map(t=>Object.assign(typeof t=="string"?{name:t}:t,{role:"bkp"})),publisher:d(s("publish-info publisher")),published:g(s("title-info date")),modified:g(s("document-info date")),description:w?a.convert(w,{annotation:["div",L]}).innerHTML:null,subject:p("title-info genre").map(d)},s("coverpage image")){const t=a.getImageSrc(s("coverpage image"));e.getCover=()=>fetch(t).then(r=>r.blob())}else e.getCover=()=>null;const y=Array.from(n.querySelectorAll("body"),t=>{const r=a.convert(t,{body:["body",$]});return[Array.from(r.children,o=>{const i=[o,...o.querySelectorAll("[id]")].map(l=>l.id);return{el:o,ids:i}}),r]}),f=[],A=y[0][0].map(({el:t,ids:r})=>{const o=Array.from(t.querySelectorAll(":scope > section > .title"),(i,l)=>(i.setAttribute(q,l),{title:d(i),index:l}));return{ids:r,titles:o,el:t}}).concat(y.slice(1).map(([t,r])=>{const o=t.map(i=>i.ids).flat();return r.classList.add("notesBodyType"),{ids:o,el:r,linear:"no"}})).map(({ids:t,titles:r,el:o,linear:i})=>{const l=E(o.outerHTML),h=new Blob([l],{type:T.XHTML}),x=URL.createObjectURL(h);f.push(x);const b=k(o.querySelector(".title, .subtitle, p")?.textContent??(o.classList.contains("title")?o.textContent:""));return{ids:t,title:b,titles:r,load:()=>x,createDocument:()=>new DOMParser().parseFromString(l,T.XHTML),size:h.size-Array.from(o.querySelectorAll("[src]"),v=>v.getAttribute("src")?.length??0).reduce((v,M)=>v+M,0),linear:i}}),C=new Map;return e.sections=A.map((t,r)=>{const{ids:o,load:i,createDocument:l,size:h,linear:x}=t;for(const b of o)b&&C.set(b,r);return{id:r,load:i,createDocument:l,size:h,linear:x}}),e.toc=A.map(({title:t,titles:r},o)=>{const i=o.toString();return{label:t,href:i,subitems:r?.length?r.map(({title:l,index:h})=>({label:l,href:`${i}#${h}`})):null}}).filter(t=>t),e.resolveHref=t=>{const[r,o]=t.split("#");return r?{index:Number(r),anchor:i=>i.querySelector(`[${q}="${o}"]`)}:{index:C.get(o),anchor:i=>i.getElementById(o)}},e.splitTOCHref=t=>t?.split("#")?.map(r=>Number(r))??[],e.getTOCFragment=(t,r)=>t.querySelector(`[${q}="${r}"]`),e.isExternal=t=>/^\w+:/i.test(t),e.destroy=()=>{for(const t of f)URL.revokeObjectURL(t)},e};export{j as makeFB2};
//# sourceMappingURL=fb2-BK8t9eR6.chunk.mjs.map
